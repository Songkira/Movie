<template>
  <div>
    <h1 style="color:white">없습니다.</h1>
  </div>
</template>

<script>
export default {
  name: 'viewF404'
}
</script>

<style>

</style>